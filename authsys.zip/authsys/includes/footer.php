<script src="assets/js/mock.js"></script>
<script src="assets/js/jquery-2.1.4.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/jquery.validate.min.js"></script>
<script src="assets/js/jquery.slimscroll.min.js"></script>
<script src="assets/js/jquery.dropdown.js"></script>
<!-- App Js -->
<script src="assets/js/jquery.app.js"></script>
<script src="assets/js/main.js"></script>
