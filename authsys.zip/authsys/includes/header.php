<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
        <title>User</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
<!-- <link rel="shortcut icon" href="assets/images/favicon.ico"> -->

<!-- Bootstrap core CSS -->
<link href="assets/css/jquerysctipttop.css" rel="stylesheet">
<link href="assets/css/bootstrap.min.css" rel="stylesheet">
<!-- Icons CSS -->
<link href="assets/css/icons.css" rel="stylesheet">
<!-- Custom styles for this template -->
<link href="assets/css/style.css" rel="stylesheet">
<link href="assets/css/jquery.dropdown.css" rel="stylesheet">
</head>
<body>