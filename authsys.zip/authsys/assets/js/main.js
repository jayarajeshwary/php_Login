function showpassword() {
  var x = document.getElementById("pword");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
$('.dropdown-mul-1').dropdown({
  limitCount: 40,
  multipleMode: 'label',
  choice: function () {
     //console.log(arguments,this);
  }
});

$('.dropdown-mul-2').dropdown({
  limitCount: 40,
  multipleMode: 'label',
  choice: function () {
     //console.log(arguments,this);
  }
});

$('#user').validate({
    rules: {
        'fname': 'required',
        'lname': 'required',
        'email_id': {
            required: true,
            email: true
        },
        'pword':'required',
        'emp_id':'required',
        'ldap_id':'required',
        'default_site_id':'required',
        'site_ids':'required',
        'default_approle_id':'required',
        'approle_ids':'required',


    },
    messages: {
        'fname': 'First name is required.',
        'lname': 'Last name is required.',
        'pword': 'Password is required.',
        'emp_id': 'Employee ID is required.',
        'ldap_id': 'LDAP ID is required.',
        'default_site_id': 'Default site is required.',
        'site_ids': 'Site access is required.',
        'default_approle_id': 'Default approle is required.',
        'approle_ids': 'Roles is required.',

        'email_id': {
            required: 'Email is required.',
            email: 'A valid email is required.'
        }
    }
});